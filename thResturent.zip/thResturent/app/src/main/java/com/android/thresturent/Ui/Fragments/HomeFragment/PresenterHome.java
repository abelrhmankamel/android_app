package com.android.thresturent.Ui.Fragments.HomeFragment;

import android.text.TextUtils;
import android.util.Log;

import com.android.thresturent.common.model.Advertising;
import com.android.thresturent.common.model.MainResponse;
import com.android.thresturent.common.network.WebService;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class PresenterHome implements HomeContract.Presenter {
    HomeContract.Model.onFinishedListener mModel;
    HomeContract.View mView;

    public PresenterHome(HomeContract.Model.onFinishedListener mModel, HomeContract.View mView) {
        this.mModel = mModel;
        this.mView = mView;
    }

    @Override
    public void performGetAds() {
        mView.showProgress();
        WebService.getInstance(false).getApi().getAds().enqueue(new Callback<List<Advertising>>() {
            @Override
            public void onResponse(Call<List<Advertising>> call, Response<List<Advertising>> response) {
                mModel.loadAds(response.body());
                mView.hideProgress();
            }

            @Override
            public void onFailure(Call<List<Advertising>> call, Throwable t) {
                mView.hideProgress();
            }
        });
    }
    @Override
    public void deleteAds(String id) {
        mView.showProgress();
        if(TextUtils.isEmpty(id)){
            mView.hideProgress();

        }else{
            WebService.getInstance(true).getApi().deleteOffer(Integer.parseInt(id)).enqueue(new Callback<MainResponse>() {
                @Override
                public void onResponse(Call<MainResponse> call, Response<MainResponse> response) {
                    mModel.onFinished(response.body().message);
                    mView.hideProgress();
                }

                @Override
                public void onFailure(Call<MainResponse> call, Throwable t) {

                    Log.e(TAG, "onFailure: "+t.getMessage() );
                    mView.hideProgress();
                }
            });
        }
    }
}
