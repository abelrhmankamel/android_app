package com.android.thresturent.Ui.Acivities.MainRegistration;

public interface ViewMainRegistration {
    void initialView();
    void setListener();
}
