package com.android.thresturent.common.network;

//this class contain the URL the server to access api to server
public class Urls {
    public static final String MAIN_URL ="https://endpoint.develogs.com/restaurant/";
    public static final String IMAGE_URL="https://endpoint.develogs.com/restaurant/uploads/";
}
