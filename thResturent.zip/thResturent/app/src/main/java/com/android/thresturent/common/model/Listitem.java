package com.android.thresturent.common.model;

public class Listitem {
    public String id;
    public String name;

    public Listitem(String id,String name) {
        this.name = name;
        this.id = id;
    }
}
