package com.android.thresturent.Ui.Fragments.HomeFragment;


import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.thresturent.Ui.Fragments.MenuFragment.MenuFragment;
import com.android.thresturent.R;
import com.android.thresturent.common.base.BaseFragment;
import com.android.thresturent.common.helper.AppPreferences;
import com.android.thresturent.common.helper.Constants;
import com.android.thresturent.common.helper.Message;
import com.android.thresturent.common.model.Advertising;
import com.android.thresturent.common.model.LoginResponse;

import java.util.List;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends BaseFragment implements HomeContract.View,HomeContract.Model.onFinishedListener , AdvertisingAdapter.AdvertisingInterAction {


    public static HomeFragment newInstance() {
        return new HomeFragment();
    }

    private Button btnOrderNow;
    private ImageView phoneImageNo;
    private TextView phoneNo;
    private RecyclerView recyclerView;
    private PresenterHome presenter;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        initializeViews(view);
        setListeners();
        return view;
    }

    @Override
    protected void initializeViews(View v) {
        NotificationManager notificationManager = (NotificationManager) getActivity().getSystemService(NOTIFICATION_SERVICE);
        notificationManager.cancelAll();
        btnOrderNow = v.findViewById(R.id.btn_order_now);
        recyclerView = v.findViewById(R.id.recycler_advertising);
        phoneImageNo = v.findViewById(R.id.phone_img_no);
        phoneNo = v.findViewById(R.id.phone_no);
        swipeRefreshLayout = v.findViewById(R.id.swipe);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        presenter = new PresenterHome(this,this);
        presenter.performGetAds();
        swipeRefreshLayout.setEnabled(false);
    }

    @Override
    protected void setListeners() {
        btnOrderNow.setOnClickListener(btnOrderNowListener);
        phoneImageNo.setOnClickListener(phoneNoListener);
        phoneNo.setOnClickListener(phoneNoListener);
    }

    private View.OnClickListener phoneNoListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent callIntent = new Intent(Intent.ACTION_DIAL);
            callIntent.setData(Uri.parse("tel:"+"01289524583"));
            startActivity(callIntent);
        }
    };
    private View.OnClickListener btnOrderNowListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            replaceFragment(R.id.container_body, MenuFragment.newInstance(),String.valueOf(Constants.NavigationConstants.ACTION_MENU_ITEM));
        }
    };


    @Override
    public void onFinished(String result) {
        Message.message(getActivity(),result);
        if(result.equals("delete room Successfully !")){
            Reload();
        }
    }

    @Override
    public void onFailuer(Throwable t) {

    }

    @Override
    public void loadAds(List<Advertising> advertisings) {

        AdvertisingAdapter adapter = new AdvertisingAdapter(getActivity(),advertisings,this);
        recyclerView.setAdapter(adapter);
    }
    public void Reload(){
        getActivity().getSupportFragmentManager().beginTransaction().replace(HomeFragment.this.getId(), new HomeFragment()).commit();
    }
    @Override
    public void showProgress() {

        swipeRefreshLayout.setRefreshing(true);
    }

    @Override
    public void hideProgress() {

        swipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onClick() {
        replaceFragment(R.id.container_body,MenuFragment.newInstance(),String.valueOf(Constants.NavigationConstants.ACTION_MENU_ITEM));
    }


    @Override
    public void onDelete(final Advertising advertising) {

        if (AppPreferences.getBoolean(Constants.AppPreferences.IS_ADMIN,getActivity(),false)){
            final CharSequence option[]=new CharSequence[]{ AppPreferences.getBoolean(Constants.AppPreferences.IS_ADMIN,getActivity(),false)?"Delete offer":""};

            AlertDialog.Builder builder =new AlertDialog.Builder(getActivity());
            builder.setTitle("Menu");
            builder.setItems(option, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    switch(which){
                        case 0:
                            presenter.deleteAds(String.valueOf(advertising.getId()));
                            break;

                    }

                }
            });
            builder.show();
        }

    }
}
