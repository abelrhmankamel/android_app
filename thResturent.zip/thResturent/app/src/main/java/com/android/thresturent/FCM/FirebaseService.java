package com.android.thresturent.FCM;

import android.app.ActivityManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.util.Log;


import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import com.android.thresturent.Ui.Acivities.MainActivity.MainActivity;
import com.android.thresturent.R;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.List;

import static android.content.ContentValues.TAG;

public class FirebaseService extends FirebaseMessagingService
{
    private static int NOTIFICATION_ID =0 ;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        String title = remoteMessage.getData().get("title");
        String message = remoteMessage.getData().get("message");
        String shehab = remoteMessage.getData().get("shehab");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            generateNotification(remoteMessage.getData().get("title"),remoteMessage.getData().get("message"));
        }

        if(remoteMessage.getData().size()>0)
        {

        }
        Log.e("message Received from", remoteMessage.getFrom());
        Log.e("message Received from", remoteMessage.getData().get("message"));
    }

    private boolean isAppIsInBackground(Context context)
    {
        boolean isInBackground = true;
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            List<ActivityManager.RunningAppProcessInfo> runningAppProcess = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo:runningAppProcess)
            {
                if(processInfo.importance== ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND)
                {
                    for (String activeProcess:processInfo.pkgList)
                    {
                        if(activeProcess.equals(context.getPackageName()))
                        {
                            isInBackground=false;

                        }
                    }
                }
            }        }



        if(Build.VERSION.SDK_INT> Build.VERSION_CODES.KITKAT_WATCH)
        {
            List<ActivityManager.RunningAppProcessInfo> runningAppProcess = am.getRunningAppProcesses();
            for (ActivityManager.RunningAppProcessInfo processInfo:runningAppProcess)
            {
                if(processInfo.importance== ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND)
                {
                    for (String activeProcess:processInfo.pkgList)
                    {
                        if(activeProcess.equals(context.getPackageName()))
                        {
                            isInBackground=false;

                        }
                    }
                }
            }
        }else
        {
            List<ActivityManager.RunningTaskInfo> taskInfos = am.getRunningTasks(1);
            ComponentName componentInfo = taskInfos.get(0).topActivity;
            if (componentInfo.getPackageName().equals(context.getPackageName()));
            {
                isInBackground=false;
            }
        }
        return isInBackground;
    }


    private NotificationManager mNotificationManager;
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void generateNotification(String title, String message) {



        NotificationCompat.Builder mBuilder =
                new NotificationCompat.Builder(getApplicationContext(), "notify_001");
        Intent ii = new Intent(getApplicationContext(), MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, ii, 0);

        NotificationCompat.BigTextStyle bigText = new NotificationCompat.BigTextStyle();
        bigText.bigText(message);
        bigText.setBigContentTitle(title);
        bigText.setSummaryText("new notification");

        mBuilder.setContentIntent(pendingIntent);
        mBuilder.setSmallIcon(R.drawable.restaurant_logo);
        mBuilder.setContentTitle("Your Title");
        mBuilder.setContentText("Your text");
        mBuilder.setPriority(Notification.PRIORITY_MAX);
        mBuilder.setStyle(bigText);
        mBuilder.setColor(ContextCompat.getColor(getApplicationContext(), R.color.colorPrimaryDark));

        mNotificationManager =
                (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);


// === Removed some obsoletes
        Uri sound = Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + getPackageName() + "/" + R.raw.notification_sound);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {

            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();
            String channelId = "12";
            mNotificationManager.cancelAll();
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    "new channel",
                    NotificationManager.IMPORTANCE_HIGH);



            channel.setDescription("msg");
            channel.enableLights(true);
            channel.enableVibration(true);
            channel.setSound(sound, attributes);


            mNotificationManager.createNotificationChannel(channel);



            mBuilder.setChannelId(channelId);
        }

        mNotificationManager.notify(0, mBuilder.build());
//        if (mNotificationManager != null) {
//            List<NotificationChannel> channelList = mNotificationManager.getNotificationChannels();
//
//            for (int i = 0; channelList != null && i < channelList.size(); i++) {
//                mNotificationManager.deleteNotificationChannel(channelList.get(i).getId());
//            }
//        }
    }

}
